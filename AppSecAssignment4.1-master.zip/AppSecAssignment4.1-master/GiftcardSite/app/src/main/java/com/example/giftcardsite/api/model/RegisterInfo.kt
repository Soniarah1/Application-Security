package com.example.giftcardsite.api.model

class RegisterInfo(val username: String, val email: String, val password: String, val password2: String)