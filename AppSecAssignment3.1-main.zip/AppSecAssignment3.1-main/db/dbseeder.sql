create table LegacySite_product_copy as select * from LegacySite_product;
insert into LegacySite_product_copy values (8,'AppSec Assignment 3','/images/product_8.jpg',1823,'this is part 2 test');
​
